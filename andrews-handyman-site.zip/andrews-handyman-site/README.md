# Andrew’s Handyman Services Website Package

## Structure
- `index.html` — Your main static website file.
- `logo.jpeg` — Your business logo.
- `images/` — Place your project photos here as:
  - `project1.jpg`
  - `project2.jpg`
  - `project3.jpg`
  - `project4.jpg`

## How to Deploy with GitHub Pages
1. Create a GitHub account if you don’t have one.
2. Create a new repository (e.g., `andrews-handyman-site`).
3. Upload **all files and folders** from this package.
4. Go to **Settings > Pages**, select the `main` branch and root (`/`) folder, click **Save**.
5. Your site will be live at: `https://<your-username>.github.io/andrews-handyman-site/`

Feel free to customize further. Good luck!
